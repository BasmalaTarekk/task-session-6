--Assignment Session 6 

--1 
USE StoreDB
SELECT 
 customer_id,
 SUM(quantity * list_price * (1 - discount)) AS total_spent,
 CASE 
   WHEN SUM(quantity * list_price * (1 - discount)) > 5000 THEN 'VIP Customer'
   ELSE 'Regular Customer'
 END AS customer_type
FROM sales.orders o
JOIN sales.order_items oi ON o.order_id = oi.order_id
WHERE customer_id = 1
GROUP BY customer_id;

-------------------------------------------------------------
--2
DECLARE @price_threshold INT;
SET @price_threshold = 1500;
SELECT 
 @price_threshold AS Threshold_Price,
 COUNT(*) AS Products_Above_Threshold,
 CONCAT('Number of products costing more than $', @price_threshold, ': ', COUNT(*)) AS Message
FROM production.products
WHERE list_price > @price_threshold;

----------------------------------------------------------------
--3 
DECLARE @staff_id INT = 2;
DECLARE @year INT = 2017;
DECLARE @total_sales DECIMAL(18,2);

SELECT @total_sales = SUM(oi.quantity * oi.list_price * (1 - oi.discount))
FROM sales.orders o
JOIN sales.order_items oi ON o.order_id = oi.order_id
WHERE o.staff_id = @staff_id
AND YEAR(o.order_date) = @year;

SELECT 
 @staff_id AS Staff_ID,
 @year AS Year,
 ISNULL(@total_sales, 0) AS Total_Sales,
 CONCAT('Total sales for staff member ', @staff_id, ' in ', @year, ': $', FORMAT(ISNULL(@total_sales, 0), 'N2')) AS Message;

 ---------------------------------------------------------------
 --4
SELECT 
  @@SERVERNAME AS Server_Name,
  @@VERSION AS SQL_Server_Version, 
  @@ROWCOUNT AS Rows_Affected_last_Statement;

SELECT * FROM production.products WHERE list_price > 1000;

-----------------------------------------------------------------
--5
SELECT product_id, store_id, quantity,
 CASE 
  WHEN quantity > 20  THEN 'Well stocked'
  WHEN quantity BETWEEN 10 AND 20 THEN 'Moderate stock'
  WHEN quantity < 10  THEN 'Low stock - reorder needed'
 END AS Stock_status
FROM production.stocks
WHERE product_id = 1 AND store_id = 1;

------------------------------------------------------------------
--6 
DECLARE @ProductsToUpdate TABLE (
 id INT IDENTITY(1,1), product_id INT, store_id INT
 );
INSERT INTO @ProductsToUpdate (product_id, store_id)
SELECT product_id, store_id
FROM production.stocks
WHERE quantity < 5;

DECLARE @Total INT = (SELECT COUNT(*) FROM @ProductsToUpdate );
DECLARE @Counter INT = 1;

WHILE @Counter <= @Total
BEGIN
  UPDATE s
  SET s.quantity = s.quantity + 10
  FROM production.stocks s
  JOIN (
    SELECT TOP 3 product_id, store_id
    FROM @ProductsToUpdate
    WHERE id >= @Counter
    ORDER BY id  ) AS batch
 ON s.product_id = batch.product_id AND s.store_id = batch.store_id;

   PRINT CONCAT('Updated batch starting from item #', @Counter);
   SET @Counter = @Counter + 3;
END
---------------------------------------------------------------------
--7
SELECT 
   product_id, product_name, list_price,
   CASE 
     WHEN list_price < 300 THEN 'Budget'
     WHEN list_price BETWEEN 300 AND 800 THEN 'Mid-Range'
     WHEN list_price BETWEEN 801 AND 2000 THEN 'Premium'
     WHEN list_price > 2000 THEN 'Luxury'
   END AS price_category
FROM production.products;

---------------------------------------------------------------------
--8 
DECLARE @CustomerID INT = 5;
DECLARE @OrderCount INT;

IF EXISTS (SELECT 1 FROM sales.customers WHERE customer_id = @CustomerID)
BEGIN
   SELECT @OrderCount = COUNT(*)
   FROM sales.orders
   WHERE customer_id = @CustomerID;
   SELECT CONCAT('Customer', @CustomerID, 'has', @OrderCount, 'orders.') AS Message;
END
ELSE
BEGIN 
   SELECT CONCAT('Customer', @CustomerID, 'does not exist in the database') AS Message;
END
-----------------------------------------------------
--9 
CREATE FUNCTION CalculateShipping2 (@OrderTotal DECIMAL(10,2))
RETURNS DECIMAL(10,2)
AS 
BEGIN
   DECLARE @ShippingCost DECIMAL(10,2);

   IF @OrderTotal > 100
         SET @ShippingCost = 0;
   ELSE IF @OrderTotal BETWEEN 50 AND 99.99
         SET @ShippingCost = 5.99;
   ELSE      
         SET @ShippingCost = 12.99;
   RETURN @ShippingCost;
END;
--------------------------------------------------------
--10
CREATE FUNCTION dbo.GetProductsByPriceRange
 (  @MinPrice DECIMAL(10,2), @MaxPrice DECIMAL(10,2) 
 )
 RETURNS TABLE 
 AS 
 RETURN (
     SELECT
     p.product_id, p.product_name, p.list_price, b.brand_name, c.category_name
     FROM production.products p 
     JOIN production.brands b ON p.brand_id = b.brand_id
     JOIN production.categories c ON p.category_id = c.category_id
     WHERE p.list_price BETWEEN @MinPrice AND @MaxPrice 
    );
---------------------------------------------------------
--11
---------------------------------------------------------
--12
CREATE FUNCTION dbo.CalculateBulkDiscount (@Quntity INT)
RETURNS DECIMAL(5,2)
AS 
BEGIN
   DECLARE @Discount DECIMAL(5,2);
   IF @Quntity BETWEEN 1 AND 2 
     SET @Discount = 0;
  ELSE IF @Quntity BETWEEN 3 AND 5 
     SET @Discount = 5.00;
  ELSE IF @Quntity BETWEEN 6 AND 9
     SET @Discount = 10.00;
  ELSE IF @Quntity >= 10 
     SET @Discount = 15.00;
  ELSE 
     SET @Discount = 0;
  RETURN @Discount;
END;
-------------------------------------------------------------
--13
USE StoreDB;
GO
CREATE PROCEDURE sp_GetCustomerOrderHistory
    @CustomerID INT,
    @StartDate DATE = NULL,
    @EndDate DATE = NULL
AS
BEGIN
    SET NOCOUNT ON;

    SELECT 
        o.order_id,
        o.order_date,
        SUM(od.list_price * od.quantity * (1 - ISNULL(od.discount, 0))) AS OrderTotal
    FROM 
        sales.orders o
    INNER JOIN 
       sales.order_items od ON o.order_id = od.order_id
    WHERE 
        o.customer_id = @CustomerID
        AND (@StartDate IS NULL OR o.order_date >= @StartDate)
        AND (@EndDate IS NULL OR o.order_date <= @EndDate)
    GROUP BY 
        o.order_id, o.order_date
    ORDER BY 
        o.order_date;
END;
-------------------------------------------------------------
--14
CREATE PROCEDURE sp_RestockProduct
  @StoreID INT,
  @ProductID INT, 
  @RestockQty INT,
  @OldQty INT OUTPUT,
  @NewQty INT OUTPUT,
  @Success BIT OUTPUT
AS
BEGIN 
      SET NOCOUNT ON;
    DECLARE @CurrentQty INT;
     SELECT @CurrentQty = quantity
    FROM production.stocks
    WHERE store_id = @StoreID AND product_id = @ProductID;
 IF @CurrentQty IS NOT NULL
 BEGIN
    SET @OldQty = @CurrentQty;
    SET @NewQty = @CurrentQty + @RestockQty;
    UPDATE production.stocks
    SET quantity = @NewQty
    WHERE store_id = @StoreID AND product_id = @ProductID;
         SET @Success = 1;  
    END
    ELSE
    BEGIN
        SET @OldQty = 0;
        SET @NewQty = 0;
        SET @Success = 0;  
    END
END;
-------------------------------------------------------------
--15
CREATE PROCEDURE sp_ProcessNewOrder
    @CustomerID INT,
    @ProductID INT,
    @Quantity INT,
    @StoreID INT,
AS
BEGIN
   SET NOCOUNT ON;
   BEGIN TRY
      BEGIN TRANSACTION;

      DECLARE @AvailableQty INT;
      SELECT @AvailableQty = quantity
      FROM production.stocks
      WHERE product_id = @ProductID AND store_id = @StoreID;

    IF @AvailableQty IS NULL 
    BEGIN 
        THROW 50001, 'Product or Store not found in inventory.', 1;
      END
    IF @AvailableQty < @Quantity
    BEGIN
        THROW 50002, 'Insufficient quantity available in inventory.', 1;
      END
-------------------------------------------------------------
--16

CREATE PROCEDURE sp_SearchProducts
     @ProductName NVARCHAR(100) = NULL,
     @CategoryID INT = NULL,
     @MinPrice DECIMAL(10, 2) = NULL,
     @MaxPrice DECIMAL(10, 2) = NULL,
     @SortColumn NVARCHAR(50) = NULl
AS
BEGIN
  SET NOCOUNT ON;
    DECLARE @SQL NVARCHAR(MAX);
    DECLARE @WhereClause NVARCHAR(MAX) = '';
    DECLARE @OrderByClause NVARCHAR(MAX) = '';
   
    IF @ProductName IS NOT NULL
        SET @WhereClause += ' AND ProductName LIKE ''%' + REPLACE(@ProductName, '''', '''''') + '%''';

    IF @CategoryID IS NOT NULL
        SET @WhereClause += ' AND CategoryID = ' + CAST(@CategoryID AS NVARCHAR);

    IF @MinPrice IS NOT NULL
        SET @WhereClause += ' AND Price >= ' + CAST(@MinPrice AS NVARCHAR);

    IF @MaxPrice IS NOT NULL
        SET @WhereClause += ' AND Price <= ' + CAST(@MaxPrice AS NVARCHAR);

    IF @SortColumn IS NOT NULL
        SET @OrderByClause = ' ORDER BY ' + QUOTENAME(@SortColumn);
    ELSE
        SET @OrderByClause = ' ORDER BY product_name'; -- default sorting

    SET @SQL = '
        SELECT  product_name, category_id, list_price
        FROM production.products
        WHERE 1=1' + @WhereClause + @OrderByClause;

    EXEC sp_executesql @SQL;
END
-------------------------------------------------------------
--17
-------------------------------------------------------------
--18
SELECT
  p.product_id, product_name, category_id , quantity,
   CASE
    WHEN category_id = 'Electronics' THEN
      CASE
        WHEN quantity < 10 THEN 50
        WHEN quantity BETWEEN 10 AND 20 THEN 30
        ELSE 0
      END
    WHEN category_id = 'Groceries' THEN
      CASE
        WHEN quantity < 50 THEN 100
        WHEN quantity BETWEEN 50 AND 100 THEN 50
        ELSE 0
      END

    WHEN category_id = 'Clothing' THEN
      CASE
        WHEN quantity < 20 THEN 40
        WHEN quantity BETWEEN 20 AND 40 THEN 20
        ELSE 0
      END
    ELSE 0  
  END AS reorder_quantity
FROM production.products p , production.stocks;
-------------------------------------------------------------
--19
SELECT
  c.customer_id,
  CONCAT(c.first_name, ' ', c.last_name) AS customer_name,
  COALESCE(SUM(o.total_amount), 0) AS total_spent,

  CASE
    WHEN COALESCE(SUM(o.total_amount), 0) = 0 THEN 'Bronze'
    WHEN COALESCE(SUM(o.total_amount), 0) BETWEEN 1 AND 4999 THEN 'Silver'
    WHEN COALESCE(SUM(o.total_amount), 0) BETWEEN 5000 AND 9999 THEN 'Gold'
    WHEN COALESCE(SUM(o.total_amount), 0) >= 10000 THEN 'Platinum'
    ELSE 'Bronze'
  END AS loyalty_tier

FROM sales.customers c
LEFT JOIN sales.orders o ON c.customer_id = o.customer_id
GROUP BY c.customer_id, c.first_name, c.last_name
ORDER BY total_spent DESC;
-------------------------------------------------------------
--20
CREATE PROCEDURE ManageProductDiscontinuation
  @product_id INT,
  @replacement_product_id INT = NULL 
AS
BEGIN
  SET NOCOUNT ON;

  DECLARE @pendingOrdersCount INT;
  DECLARE @msg NVARCHAR(500);

  SELECT @pendingOrdersCount = COUNT(*)
  FROM sales.orders o
  JOIN sales.order_items oi ON o.order_id = oi.order_id
  WHERE oi.product_id = @product_id
    AND o.order_status = 'Pending'; 

  IF @pendingOrdersCount > 0
  BEGIN
    SET @msg = CONCAT('Found ', @pendingOrdersCount, ' pending orders for the product.');

    IF @replacement_product_id IS NOT NULL
    BEGIN
      UPDATE sales.order_items
      SET product_id = @replacement_product_id
      WHERE product_id = @product_id
        AND order_id IN (
          SELECT order_id FROM sales.orders WHERE status = 'Pending'
        );

      SET @msg = CONCAT(@msg, ' Pending orders updated with replacement product.');
    END
    ELSE
    BEGIN
      SET @msg = CONCAT(@msg, ' No replacement product provided; pending orders remain unchanged.');
    END
  END
  ELSE
  BEGIN
    SET @msg = 'No pending orders found for the product.';
  END
  UPDATE production.stocks
  SET quantity = 0
  WHERE product_id = @product_id;

  SET @msg = CONCAT(@msg, ' Inventory cleared.');
  UPDATE production.products
  SET discontinued = 1
  WHERE product_id = @product_id;

  SET @msg = CONCAT(@msg, ' Product marked as discontinued.');
  SELECT @msg AS StatusMessage;
END;
-------------------------------------------------------------


